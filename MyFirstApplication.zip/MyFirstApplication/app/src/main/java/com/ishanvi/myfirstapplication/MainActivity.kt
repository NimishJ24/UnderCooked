package com.ishanvi.myfirstapplication

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity(){

    lateinit var txtForgotP: TextView
    lateinit var txtNoAccount: TextView
    lateinit var btLogin: Button
    lateinit var etPassword: EditText
    lateinit var etMobileNum:EditText
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        sharedPreferences=getSharedPreferences(getString(R.string.preference_file_name ), Context.MODE_PRIVATE)
        val intent=Intent(this@MainActivity,Welcome2::class.java)
        val loggedIn=sharedPreferences.getBoolean("loggedIn",false)
        if(loggedIn){

            startActivity(intent)
            finish()


        }


        txtForgotP=findViewById(R.id.txtForgotP)
        txtNoAccount=findViewById(R.id.txtNoAccount)
        etPassword=findViewById(R.id.etPassword)
        etMobileNum=findViewById(R.id.etMoblieNum)
        btLogin=findViewById(R.id.btLogin)

        btLogin.setOnClickListener {
            val mobilenum=etMobileNum.text.toString()
            val password=etPassword.text.toString()
            var list= listOfNotNull(mobilenum,password)
            if(list.contains(""))
            {
                Toast.makeText(this@MainActivity,"Invalid Credentials",Toast.LENGTH_LONG).show()

            }
            else{
                sharedPreferences.edit().putBoolean("loggedIn",true).apply()
                sharedPreferences.edit().putString("MobileNum",mobilenum).apply()
                startActivity(intent)
                finish()
            }
        }


        txtForgotP.setOnClickListener{
            val intentForgotP= Intent(this@MainActivity,ForgotPassword::class.java)
            startActivity(intentForgotP)
        }
        txtNoAccount.setOnClickListener{
            val intentNoAcc= Intent(this@MainActivity,RegisterYourself::class.java)
            startActivity(intentNoAcc)
        }

    }



}